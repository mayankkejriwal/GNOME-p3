flag_config_dict = dict()
flag_config_dict['failure_code'] = -1
flag_config_dict['successful_action'] = 1
flag_config_dict['skip_turn'] = 2
